<?php include ROOT . '/views/layouts/header.php'; ?>

<section>
    <div class="container">
        <div class="row">

            <div class="col-sm-12 padding-right">

                <?php if ($result): ?>
                    <p>Сообщение отправлено! Мы ответим Вам на указанный email.</p>
                <?php else: ?>
                    <?php if (isset($errors) && is_array($errors)): ?>
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li> - <?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>

                    <div class="signup-form"><!--sign up form-->
						<h1>Контакты</h1>
						<div class="contact">
							<div class="col-sm-3 item-my">
								<h3>Компания</h3>
								<p>ООО АИТЭРА</p>
							</div>
							<div class="col-sm-3 item-my">
								<h3>Почта</h3>
								<p><a href="mailto:helper@aitera.com">helper@aitera.com</a></p>
							</div>
							<div class="col-sm-3 item-my">
								<h3>Общий номер</h3>
								<p>+7 (495) 223-35-57</p>
							</div>
							<div class="col-sm-3 item-my">
								<h3>Где мы находимся</h3>
								<p>Москва, Луговой пр-д , д.5 , стр.1</p>
							</div>
							<div class="col-sm-12 item-my">
								<h3>Режим работы</h3>
								<p>Пн-Пт, С 9:00 до 19:00</p>
							</div>
							
						</div>
						
						<div class="col-sm-12 right-content">
							<h2>Как до нас дорбраться:</h2>
							<iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A81bd20af49027bf7d26f05a4235659f48ebc17f87fab63a905b3f17d5d2e79be&amp;source=constructor" width="100%" height="500" frameborder="0"></iframe>
						</div>

                    </div><!--/sign up form-->
                <?php endif; ?>


                <br/>
                <br/>
            </div>
        </div>
    </div>
</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>