<?php include ROOT . '/views/layouts/header.php'; ?>

<script>
$(document).ready(function() {
 // executes when HTML-Document is loaded and DOM is ready
 alert("Сайт находиться в разработке и услуги еще не работают");
 $('#myTab a[href="#profile"]').tab('show');
});
</script>



<section>

<style type="text/css">
.slider
{
	margin-bottom: 25px;
}

@keyframes slidy
{
    0%
    {
        left: 0;
    }

    20%
    {
        left: 0;
    }

    25%
    {
        left: -100%;
    }

    45%
    {
        left: -100%;
    }

    50%
    {
        left: -200%;
    }

    70%
    {
        left: -200%;
    }

    75%
    {
        left: -300%;
    }

    95%
    {
        left: -300%;
    }

    100%
    {
        left: -400%;
    }
}

div.slider
{
    overflow: hidden;
}

div.slider figure img
{
    float: left;

    width: 20%;
}

div.slider figure
{
    font-size: 0;

    position: relative;
    left: 0;

    width: 500%;
    margin: 0;

    animation: 30s slidy infinite;
    text-align: left;
}
</style>

<div class="cont_right">

	<div class="container">
		<div class="col-sm-12">
			<nav class="nav_soc">
				<ul class="nav_list_soc">
					<div class="contact-item"> <li><a href="mailto:helper@aitera.com"> <i class="fa fa-envelope"></i> E-mail</a></li> </div>
					<div class="contact-item"> <li><a href="https://wa.me/79104276158"> <i class="fa fa-whatsapp"></i> WHATSAPP</a></li> </div>
					<div class="contact-item"> <li><a href="tel:+74952233557"> <i class="fa fa-phone"></i> +7 (495) 223-35-57</a></li> </div>
					<div class="contact-item"> <li><a href="viber://chat?number=89104276158"> <i class="fa fa-comment"></i> VIBER</a></li> </div>
					<div class="contact-item"> <li><a href="https://t.me/tanjaborodina"> <i class="fa fa-telegram"></i> TELEGRAMM</a></li> </div>
				</ul>
			</nav>
		</div>
	
		<div class="slider">
			<div class="col-sm-12">
				
				<div class="col-sm-12">
					<figure>
						<img src="/template/images/slider/1.png" alt="">
						<img src="/template/images/slider/1.png" alt="">
						<img src="/template/images/slider/1.png" alt="">
						<img src="/template/images/slider/1.png" alt="">
						<img src="/template/images/slider/1.png" alt="">
					</figure>
				</div>
				
				<div class="col-sm-12">
					<a href="https://ru.freepik.com/vectors/business">Business вектор создан(а) stories - ru.freepik.com</a>
				</div>
			</div>
		</div>
	</div>
	
</section>

<section>
    <div class="container">
        <div class="row">
			<div class="col-sm-3">
                <div class="left-sidebar">
                    <h2>Каталог</h2>
                    <div class="panel-group category-products">
                        <?php foreach ($categories as $categoryItem): ?>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a href="/category/<?php echo $categoryItem['id'];?>">
                                            <?php echo $categoryItem['name'];?>
                                        </a>
                                    </h4>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="col-sm-9 padding-right">
                <div class="features_items"><!--features_items-->
                    <h2 class="title text-center">Готовые базы данных предприятий</h2>

                    <?php foreach ($latestProducts as $product): ?>
                        <div class="col-sm-4">
                            <div class="product-image-wrapper">
                                <div class="single-products">
                                    <div class="productinfo text-center">
                                        <img src="<?php echo Product::getImage($product['id']); ?>" alt="" />
                                        <h2><?php echo $product['price']; ?> <i class="fa fa-rub" aria-hidden="true"></i></h2>
                                        <p>
                                            <a href="/product/<?php echo $product['id']; ?>">
                                                <?php echo $product['name']; ?>
                                            </a>
                                        </p>
										<p><b>Отрасль: </b> <?php echo $product['description']; ?> </p>
										<p><b>Количество предприятий:</b> <?php echo $product['quantity']; ?> </p> 
										<p><b>Дата обновления:</b> <?php echo $product['date']; ?> </p>
                                        <a href="#" class="btn btn-default add-to-cart" data-id="<?php echo $product['id']; ?>"><i class="fa fa-shopping-cart"></i>В корзину</a>
                                    </div>
                                    <?php if ($product['is_new']): ?>
                                        <img src="/template/images/home/new.png" class="new" alt="" />
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>


                </div><!--features_items-->

        </div>
    </div>

</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>