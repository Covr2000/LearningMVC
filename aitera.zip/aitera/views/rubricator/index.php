<?php include ROOT . '/views/layouts/header.php'; ?>

<script>
$(document).ready(function() {
 // executes when HTML-Document is loaded and DOM is ready
 alert("Сайт находиться в разработке и услуги еще не работают");
 $('#myTab a[href="#profile"]').tab('show');
});
</script>



<script type="text/javascript" src="/template/js/rubricator/enhance.js"></script>

<script type="text/javascript" src="/template/js/rubricator/jQuery.tree.js"></script>	
<script type="text/javascript" src="/template/js/rubricator/example.js"></script>	
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

<script type="text/javascript">
			// Запуск теста на поддержку браузером скриптов
			enhance({
				loadScripts: [
					'https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js',
					'/template/js/rubricator/jQuery.tree.js',
					'/template/js/rubricator/example.js'
				],
				loadStyles: ['/template/css/rubricator/enhanced.css'],
				forcePassText: ['ON'],
				forceFailText: ['OFF']
			});   
</script>	

<section>
	<div class="container">
		<div class="col-sm-12" >
			<form >
				<input type="text" name="search" style="width: 90%;display: inline-block;border: 1px solid #ccc;box-shadow: inset 0 1px 3px #ddd;border-radius: 4px;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;padding-left: 20px;padding-right: 20px;padding-top: 12px;padding-bottom: 12px;">
				<button type="submit" style="margin: auto;display: inline;outline: none;border-radius: 5px;background: #0b1927;color: #ffffff;border: none;cursor: pointer;height: 47px;padding: 0 15px;width: 8%;"><i class="fa fa-search"></i></button>
			</form>
		</div>
		
		<div class="col-sm-12">
			<ul id="files" aria-expanded="false" > <h4>Все рублики</h4>
				<li><input type="checkbox" name="option3" value="a3"><a href="documents">Все рублики</a>
					<ul>

						<li><input type="checkbox" name="option3" value="a3"> <a href="#">ДФО</a>
							<ul>
								
								<li > <input type="checkbox" name="option3" value="a3"><a href="documents" >Амурская область</a>
									<ul>
										<li><input type="checkbox" name="option3" value="a3"> <a href="#">Зая</a></li>
										<li><input type="checkbox" name="option3" value="a3"> <a href="#">Завитинск</a></li>
										<li><input type="checkbox" name="option3" value="a3"> <a href="#">Тында</a></li>
									</ul>
								<li>
								
							</ul>
						</li>
						
						<li><input type="checkbox" name="option3" value="a3"> <a href="#">ПФО</a>
							<ul>
								<li><input type="checkbox" name="option3" value="a3"> <a href="#">Биробиджан</a></li>
							</ul>
						</li>
						
						<li><input type="checkbox" name="option3" value="a3"> <a href="#">СЗОФЗ</a>
							<ul>
								<li><input type="checkbox" name="option3" value="a3"> <a href="#">Борзя</a></li>
								<li><input type="checkbox" name="option3" value="a3"> <a href="#">Хилок</a></li>
							</ul>
						</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>

</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>