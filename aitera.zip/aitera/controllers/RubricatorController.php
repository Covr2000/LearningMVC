<?php

/**
 * Контроллер RubricatorController
 */
class RubricatorController
{

    /**
     * Action для главной страницы
     */
    public function actionIndex()
    {
		// echo "Все прекрасно работает улыбнись и сдохни.";
        // Подключаем вид
        require_once(ROOT . '/views/rubricator/index.php');
        return true;
    }

}
