<?php

/**
 * Контроллер CartController
 * Корзина
 */
class CartController
{

    /**
     * Action для добавления товара в корзину синхронным запросом<br/>
     * (для примера, не используется)
     * @param integer $id <p>id товара</p>
     */
    public function actionAdd($id)
    {
        // Добавляем товар в корзину
        Cart::addProduct($id);

        // Возвращаем пользователя на страницу с которой он пришел
        $referrer = $_SERVER['HTTP_REFERER'];
        header("Location: $referrer");
    }

    /**
     * Action для добавления товара в корзину при помощи асинхронного запроса (ajax)
     * @param integer $id <p>id товара</p>
     */
    public function actionAddAjax($id)
    {
        // Добавляем товар в корзину и печатаем результат: количество товаров в корзине
        echo Cart::addProduct($id);
        return true;
    }
    
    /**
     * Action для добавления товара в корзину синхронным запросом
     * @param integer $id <p>id товара</p>
     */
    public function actionDelete($id)
    {
        // Удаляем заданный товар из корзины
        Cart::deleteProduct($id);

        // Возвращаем пользователя в корзину
        header("Location: /cart");
    }

    /**
     * Action для страницы "Корзина"
     */
    public function actionIndex()
    {
        // Список категорий для левого меню
        $categories = Category::getCategoriesList();

        // Получим идентификаторы и количество товаров в корзине
        $productsInCart = Cart::getProducts();

        if ($productsInCart) {
            // Если в корзине есть товары, получаем полную информацию о товарах для списка
            // Получаем массив только с идентификаторами товаров
            $productsIds = array_keys($productsInCart);

            // Получаем массив с полной информацией о необходимых товарах
            $products = Product::getProdustsByIds($productsIds);

            // Получаем общую стоимость товаров
            $totalPrice = Cart::getTotalPrice($products);
        }

        // Подключаем вид
        require_once(ROOT . '/views/cart/index.php');
        return true;
    }

    /**
     * Action для страницы "Оформление покупки"
     */
    public function actionCheckout()
    {
        // Получием данные из корзины      
        $productsInCart = Cart::getProducts();

        // Если товаров нет, отправляем пользователи искать товары на главную
        if ($productsInCart == false) {
            header("Location: /");
        }

        // Список категорий для левого меню
        $categories = Category::getCategoriesList();

        // Находим общую стоимость
        $productsIds = array_keys($productsInCart);
        $products = Product::getProdustsByIds($productsIds);
        $totalPrice = Cart::getTotalPrice($products);

        // Количество товаров
        $totalQuantity = Cart::countItems();

        // Поля для формы
        $userName = false;
        $userPhone = false;
        $userComment = false;

        // Статус успешного оформления заказа
        $result = false;

        // Проверяем является ли пользователь гостем
        if (!User::isGuest()) {
            // Если пользователь не гость
            // Получаем информацию о пользователе из БД
            $userId = User::checkLogged();
            $user = User::getUserById($userId);
            $userName = $user['name'];
        } else {
            // Если гость, поля формы останутся пустыми
            $userId = false;
        }

        // Обработка формы
        if (isset($_POST['submit'])) {
            // Если форма отправлена
            // Получаем данные из формы
            $userName = $_POST['userName'];
            $userPhone = $_POST['userPhone'];
            $userComment = $_POST['userComment'];
            
            $userСompany = $_POST['userСompany'];
            $userAddress = $_POST['userAddress'];
            $userEmail = $_POST['userEmail'];
            $userComment = $_POST['userComment'];
            $RadioPointDelivery = $_POST['delivery'];
            
            if($RadioPointDelivery == 1){
                $crg = 450;
                $RadioPointDelivery = 'Доставка курьером';
            } else {
               $RadioPointDelivery = 'Самовывоз'; 
            }
            
            // Флаг ошибок
            $errors = false;

            // Валидация полей
            if (!User::checkName($userName)) {
                $errors[] = 'Неправильное имя';
            }
            if (!User::checkPhone($userPhone)) {
                $errors[] = 'Неправильный телефон';
            }
            
			
			/*
			$productsList =
			$products =

            */
            if ($errors == false) {
                // Если ошибок нет
                // Сохраняем заказ в базе данных
                $result = Order::save($userName, $userPhone, $userComment, $userId, $productsInCart);
                
                if ($result) {
                    // Если заказ успешно сохранен
                    // Оповещаем администратора о новом заказе по почте 
                    
                    $today = date("F j, Y, g:i a");
                    
                    mail(
                        'pavel1999bel@gmail.com',
                        'Письмо из скрипта',
                        '
                        <html>
                        <body>
                        
                        Новый заказ<br />
                        Поступил новый заказ с сайта Аитэра<br /> <br />
                        
                        
                        
                        
                        
                        <html>
                        <title>Заказ</title>
                        
                        <head></head>
                        <table border=1 cellpadding=0 width=100% bordercolordark=#ffffff bordercolorlight=#003399 bordercolor=black cellspacing=0>
                          <tr>
                            <td colspan=2 align=center bgcolor=#2255cc><b><font face=Arial color=ffffff size=3>Заказ</font></b></td>
                          </tr>
                          <tr bgcolor=#ffffff>
                            <td width=400>&nbsp;&nbsp;Ф.И.О.:</td>
                            <td>&nbsp;&nbsp;'.$userName .'</td>
                          </tr>
                          <tr bgcolor=#ffffff>
                            <td>&nbsp;&nbsp;Компания:</td>
                            <td>&nbsp;&nbsp;' .$userСompany .'</td>
                          </tr>
                          <tr bgcolor=#ffffff>
                            <td>&nbsp;&nbsp;Адрес:</td>
                            <td>&nbsp;&nbsp;' .$userAddress .'</td>
                          </tr>
                          <tr bgcolor=#ffffff>
                            <td>&nbsp;&nbsp;Телефон:</td>
                            <td>&nbsp;&nbsp;'. $userPhone.'</td>
                          </tr>
                          <tr bgcolor=#ffffff>
                            <td>&nbsp;&nbsp;Е-mail:</td>
                            <td>&nbsp;&nbsp;<a href=mailto:$email>'. $userEmail.'</a></td>
                          </tr>
                          <tr bgcolor=#ffffff>
                            <td>&nbsp;&nbsp;Дополнительная информация:</td>
                            <td>&nbsp;&nbsp;'. $userComment.'</td>
                          </tr>
                        </table>
                        <hr color=#502247>
                        
                        <table bordercolordark=#ffffff bordercolorlight=#2255cc border=1 bordercolor=black cellpadding=2 width=100% cellspacing=0>
                          <tr align=center class=content bgcolor=#2255cc>
                            <td><b><font color=#ffffff>Код</font></b></td>
                            <td><b><font color=#ffffff>Название базы данных</font></b></td>
                            <td><b><font color=#ffffff>Цена</font></b></td>
                          </tr>
                          
                          <tr class=content>
                            <td align=center></td>
                            <td></td>
                            <td align=center>&nbsp;</td>
                          </tr>
                          <tr class=content>
                            <td align=center></td>
                            <td></td>
                            <td align=center>&nbsp;</td>
                          </tr>
                          
                          <tr>
                            <td colspan=2 style=\'padding-left:47;font-size:13\'><b>'. $RadioPointDelivery. '</b></td>
                            <td align=center style=\'font-size:13\'><b>'. $crg. '</b></td>
                          </tr>
                        
                          <tr>
                            <td colspan=2 style=\'padding-left:47;font-size:13\'><b> Итоговая сумма:</b> </td>
                            <td align=center style=\'font-size:13\'><b>' .$totalPrice .'</b></td>
                          </tr>
                        </table>
                        
                        <hr color=#502247>
                        <table border=1 border=1 cellpadding=0 width=100% bordercolordark=#ffffff bordercolorlight=#003399 bordercolor=black cellspacing=0>
                          <tr>
                            <td colspan=2 align=center bgcolor=#2255cc><b><font color=ffffff size=3>Дополнительная информация о клиенте</font></b></td>
                          </tr>
                          <tr bgcolor=#ffffff>
                            <td width=400>&nbsp;&nbsp;IP посетителя:</td>
                            <td>&nbsp;&nbsp;' .$_SERVER['REMOTE_ADDR'] .'</td>
                          </tr>
                          <tr bgcolor=#ffffff>
                            <td>&nbsp;&nbsp;Время когда посетитель был на сайте:</td>
                            <td>&nbsp;&nbsp;' .$today .'</td>
                          </tr>
                          <tr bgcolor=#ffffff>
                            <td>&nbsp;&nbsp;Откуда отправил:</td>
                            <td>&nbsp;&nbsp;http://mirbaz.ru/</td>
                        </table>
                        
                        </html>
                        
                        
                        
                        
                        ',
                        "From: mirbaz@example.com\r\n"
                        ."Content-type: text/html; charset=utf-8\r\n"
                        ."X-Mailer: PHP mail script"
                    );

                    // Очищаем корзину
                    Cart::clear();
                }
            }
        }

        // Подключаем вид
        require_once(ROOT . '/views/cart/checkout.php');
        return true;
    }

}
