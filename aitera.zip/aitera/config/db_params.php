<?php

// Массив с параметрами подключения к базе данных
return array(
    'host' => 'localhost',
    'dbname' => 'aitera_shop',
    'user' => 'root',
    'password' => 'password',
);
